import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class TracetaRoute {

	public static final double MILES = 1.6;

	public TracetaRoute(String depart , String arrivee) throws IOException {
		
		System.setProperty("http.proxyHost", "cache.univ-lille1.fr");
		System.setProperty("http.proxyPort", "3128");
		/* Saisie utilisateur */
		String villeDepart = depart;
		String villeArrivee = arrivee;
		URL url = new URL("http://open.mapquestapi.com/directions/v2/route?key=MzJPF68KYbwEXaqFr3rasHfabgXU5dcd&from="
				+ villeDepart + "&to=" + villeArrivee);
		URLConnection c = url.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(c.getInputStream()));
		String inputLine;
		double dist = 0;
		String [] table = null ;

		while ((inputLine = in.readLine()) != null) {
			dist = Double.parseDouble(chercher(inputLine,"\"distance\""));
			table = inputLine.trim().split("\"");

		}
		System.out.println("Distance : " + dist * MILES + " Kms");
		for (int i = 0; i < table.length; i++) {
			if(table[i].equals("narrative")){
				System.out.println(table[i+2]);
			}
		}
		getMeteoOf(villeDepart);
		getMeteoOf(villeArrivee);
		in.close();

	}

	public static String chercher(String chaine, String tofound) {
		int index = chaine.indexOf(tofound);
		String tmp = "";
		for (int i = index + 11; i < chaine.length(); i++) {
			if (chaine.charAt(i) == ',') {
				break;
			}
			tmp += chaine.charAt(i);
		}
		return tmp;

	}
	public static String getMeteoOf(String ville) throws IOException{
		URL url = new URL("http://api.openweathermap.org/data/2.5/forecast/city?q="+ville+"&APPID=a627747b324b5c59cc68ae303a056581");
		URLConnection c = url.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(c.getInputStream()));
		String inputLine;
		Meteo tmp ;
		while ((inputLine = in.readLine()) != null) {
			tmp = new Meteo(ville, chercher(inputLine,"\"humidity\""),chercher(inputLine,"\"main\"").substring(4, 7) ,chercher(inputLine,"\"description\"").substring(4, 14) );
			System.out.println(tmp.toString());
		}
		in.close();
		return inputLine;
	}
	public static void main(String[] args) throws IOException {
		TracetaRoute test = new TracetaRoute("Paris", "Moscow");
	}
	

}
