
public class Meteo {
	String Ville;
	String humidite;
	int temperature;
	String globalement;

	public Meteo(String ville, String humidité, String temperature, String glob) {
		this.Ville = ville;
		this.humidite = humidité;
		this.temperature = Integer.parseInt(temperature) - 273;
		this.globalement = glob;
	}

	@Override
	public String toString() {
		return "Meteo pour " + Ville + " humidite=" + humidite + ", temperature=" + temperature + ", globalement :"
				+ globalement + "]";
	}

}
